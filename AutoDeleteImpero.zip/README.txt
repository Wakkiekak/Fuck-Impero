TERMS OF SERVICE (TOS)

1. Je accepteert dat ik op geen enkele manier verantwoordelijk ben voor eventuele problemen, schade of gevolgen die voortkomen uit het gebruik van dit programma. Gebruik is volledig op eigen risico.
2. Je accepteert dat dit programma op jouw computer mag staan. Als je dat later niet meer wilt, is dat jouw probleem.
3. Je belooft dat je mij niet gaat verraden, aangeven of op welke manier dan ook mijn vertrouwen schendt.
4. Je accepteert dat je nooit zal onthullen wie dit programma heeft gemaakt. Geheimhouding is verplicht.

ALS JE JE HIER NIET AAN HOUDT...
- Heb ik toestemming om je gegevens te leaken.
- Heb ik toestemming om je computer te gebruiken voor "Testing"
- Heb ik toestemming om je te ddossen of erger.

Door dit programma te gebruiken, verklaar je dat je deze voorwaarden hebt gelezen, begrepen en geaccepteerd.
